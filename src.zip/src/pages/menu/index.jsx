import React from 'react'
import Layout from '../../components/Layout'
import Menu from './Menu'

export default function MenuUs() {
  return (
    <Layout>
        <Menu paddings={true}/>
    </Layout>
  )
}
