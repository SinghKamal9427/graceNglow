import React from 'react'
import Layout from '../../components/Layout'
import Contact from './Contact'

export default function ContactUs() {
  return (
<Layout>
    <Contact paddings= {true}/>
</Layout>
  )
}
