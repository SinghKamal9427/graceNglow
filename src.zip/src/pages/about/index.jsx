import React from 'react'
import About from './About'
import Layout from '../../components/Layout'

export default function AboutUs() {
  return (
    <Layout>
        <About paddings = {true}/>
        </Layout>
  )
}
